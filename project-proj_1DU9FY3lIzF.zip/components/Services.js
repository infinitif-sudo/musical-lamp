function Services() {
  try {
    return (
      <section className="section-padding bg-white" data-name="services" data-file="components/Services.js">
        <div className="container-max">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[var(--text-dark)] mb-6">
              Nos Services
            </h2>
            <p className="text-xl text-[var(--text-light)] max-w-3xl mx-auto">
              Restaurant gastronomique et boutique-hôtel pour une expérience complète
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-[var(--background-light)] rounded-lg p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-[var(--primary-color)] rounded-full flex items-center justify-center mr-4">
                  <div className="icon-utensils text-2xl text-white"></div>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-[var(--text-dark)]">Restaurant</h3>
                  <p className="text-[var(--text-light)]">Cuisine italienne haut de gamme</p>
                </div>
              </div>
              
              <ul className="space-y-3 mb-6">
                <li className="flex items-center text-[var(--text-light)]">
                  <div className="icon-check text-green-600 mr-3"></div>
                  Trois salles élégantes + terrasse-jardin
                </li>
                <li className="flex items-center text-[var(--text-light)]">
                  <div className="icon-check text-green-600 mr-3"></div>
                  Menu évolutif avec spécialités italiennes
                </li>
                <li className="flex items-center text-[var(--text-light)]">
                  <div className="icon-check text-green-600 mr-3"></div>
                  Espaces privatifs pour événements
                </li>
                <li className="flex items-center text-[var(--text-light)]">
                  <div className="icon-check text-green-600 mr-3"></div>
                  Ouvert de 12h à 22h30 (23h le week-end)
                </li>
              </ul>
              
              <button 
                onClick={() => window.location.href = 'restaurant.html'}
                className="btn-primary w-full"
              >
                Découvrir le restaurant
              </button>
            </div>

            <div className="bg-[var(--background-light)] rounded-lg p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-[var(--secondary-color)] rounded-full flex items-center justify-center mr-4">
                  <div className="icon-bed text-2xl text-white"></div>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-[var(--text-dark)]">Hôtel</h3>
                  <p className="text-[var(--text-light)]">Boutique-hôtel 4 étoiles</p>
                </div>
              </div>
              
              <ul className="space-y-3 mb-6">
                <li className="flex items-center text-[var(--text-light)]">
                  <div className="icon-check text-green-600 mr-3"></div>
                  12 chambres rénovées avec balcon
                </li>
                <li className="flex items-center text-[var(--text-light)]">
                  <div className="icon-check text-green-600 mr-3"></div>
                  Climatisation, TV satellite, fibre optique
                </li>
                <li className="flex items-center text-[var(--text-light)]">
                  <div className="icon-check text-green-600 mr-3"></div>
                  Générateur de secours, eau surpresseur
                </li>
                <li className="flex items-center text-[var(--text-light)]">
                  <div className="icon-check text-green-600 mr-3"></div>
                  Parking gratuit privé et rue
                </li>
              </ul>
              
              <button 
                onClick={() => window.location.href = 'hotel.html'}
                className="btn-secondary w-full"
              >
                Découvrir l'hôtel
              </button>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Services component error:', error);
    return null;
  }
}