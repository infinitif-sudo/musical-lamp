function Contact() {
  try {
    return (
      <section id="contact" className="section-padding bg-[var(--background-light)]" data-name="contact" data-file="components/Contact.js">
        <div className="container-max">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[var(--text-dark)] mb-6">
              Nous Contacter
            </h2>
            <p className="text-xl text-[var(--text-light)] max-w-3xl mx-auto">
              Montée de Louis, face au consulat du Ghana, Quartier Louis, Libreville
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-[var(--primary-color)] rounded-lg flex items-center justify-center flex-shrink-0">
                  <div className="icon-map-pin text-xl text-white"></div>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[var(--text-dark)] mb-2">Adresse</h3>
                  <p className="text-[var(--text-light)]">
                    Montée de Louis, face au consulat du Ghana<br/>
                    Quartier Louis, Libreville, Gabon
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-[var(--primary-color)] rounded-lg flex items-center justify-center flex-shrink-0">
                  <div className="icon-phone text-xl text-white"></div>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[var(--text-dark)] mb-2">Téléphone</h3>
                  <a href="tel:+24174449864" className="text-[var(--text-light)] hover:text-[var(--primary-color)]">
                    +241 74 44 98 64
                  </a>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-[var(--primary-color)] rounded-lg flex items-center justify-center flex-shrink-0">
                  <div className="icon-clock text-xl text-white"></div>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[var(--text-dark)] mb-2">Horaires</h3>
                  <div className="text-[var(--text-light)] space-y-1">
                    <p>Lundi - Vendredi : 12h00 - 22h30</p>
                    <p>Samedi - Dimanche : 12h00 - 23h00</p>
                  </div>
                </div>
              </div>

              <div className="flex space-x-4">
                <a 
                  href="https://wa.me/24174449864" 
                  target="_blank"
                  className="bg-green-600 text-white px-6 py-3 rounded-lg flex items-center space-x-2 hover:bg-green-700 transition-colors"
                >
                  <div className="icon-message-circle text-xl"></div>
                  <span>WhatsApp</span>
                </a>
                <button 
                  onClick={() => window.location.href = 'reservation.html'}
                  className="btn-primary"
                >
                  Réserver
                </button>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-8">
              <h3 className="text-2xl font-bold text-[var(--text-dark)] mb-6">Localisation</h3>
              <div className="w-full h-64 rounded-lg overflow-hidden mb-4">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3986.841!2d9.43243!3d0.40644!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMMKwMjQnMjMuMiJOIDnCsDI1JzU2LjgiRQ!5e0!3m2!1sen!2sga!4v1640000000000!5m2!1sen!2sga"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Roma Restaurant & Hotel - Localisation"
                />
              </div>
              <p className="text-[var(--text-light)] text-center">
                Face au consulat du Ghana, Quartier Louis
              </p>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Contact component error:', error);
    return null;
  }
}
