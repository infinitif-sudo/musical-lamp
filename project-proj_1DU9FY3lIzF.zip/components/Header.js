function Header() {
  try {
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);

    const scrollToSection = (sectionId) => {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
      setIsMenuOpen(false);
    };

    const navigateToPage = (page) => {
      window.location.href = page;
    };

    return (
      <header className="bg-white shadow-md fixed w-full top-0 z-40" data-name="header" data-file="components/Header.js">
        <div className="container-max">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <div className="icon-utensils text-3xl text-[var(--primary-color)]"></div>
              <div>
                <h1 className="text-2xl font-bold text-[var(--primary-color)]">Roma</h1>
                <p className="text-sm text-[var(--text-light)]">Restaurant & Hotel</p>
              </div>
            </div>

            <nav className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('home')} className="text-[var(--text-dark)] hover:text-[var(--primary-color)] transition-colors">
                Accueil
              </button>
              <button onClick={() => scrollToSection('about')} className="text-[var(--text-dark)] hover:text-[var(--primary-color)] transition-colors">
                À propos
              </button>
              <button onClick={() => navigateToPage('restaurant.html')} className="text-[var(--text-dark)] hover:text-[var(--primary-color)] transition-colors">
                Restaurant
              </button>
              <button onClick={() => navigateToPage('hotel.html')} className="text-[var(--text-dark)] hover:text-[var(--primary-color)] transition-colors">
                Hôtel
              </button>
              <button onClick={() => navigateToPage('galerie.html')} className="text-[var(--text-dark)] hover:text-[var(--primary-color)] transition-colors">
                Galerie
              </button>
              <button onClick={() => scrollToSection('contact')} className="text-[var(--text-dark)] hover:text-[var(--primary-color)] transition-colors">
                Contact
              </button>
              <button onClick={() => navigateToPage('reservation.html')} className="btn-primary">
                Réserver
              </button>
            </nav>

            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-[var(--text-dark)]"
            >
              <div className="icon-menu text-2xl"></div>
            </button>
          </div>

          {isMenuOpen && (
            <div className="md:hidden bg-white border-t py-4">
              <div className="flex flex-col space-y-4">
                <button onClick={() => scrollToSection('home')} className="text-left text-[var(--text-dark)] hover:text-[var(--primary-color)]">
                  Accueil
                </button>
                <button onClick={() => scrollToSection('about')} className="text-left text-[var(--text-dark)] hover:text-[var(--primary-color)]">
                  À propos
                </button>
                <button onClick={() => navigateToPage('restaurant.html')} className="text-left text-[var(--text-dark)] hover:text-[var(--primary-color)]">
                  Restaurant
                </button>
                <button onClick={() => navigateToPage('hotel.html')} className="text-left text-[var(--text-dark)] hover:text-[var(--primary-color)]">
                  Hôtel
                </button>
                <button onClick={() => navigateToPage('galerie.html')} className="text-left text-[var(--text-dark)] hover:text-[var(--primary-color)]">
                  Galerie
                </button>
                <button onClick={() => scrollToSection('contact')} className="text-left text-[var(--text-dark)] hover:text-[var(--primary-color)]">
                  Contact
                </button>
                <button onClick={() => navigateToPage('reservation.html')} className="btn-primary w-full">
                  Réserver
                </button>
              </div>
            </div>
          )}
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}