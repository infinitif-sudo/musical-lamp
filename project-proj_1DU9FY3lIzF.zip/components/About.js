function About() {
  try {
    return (
      <section id="about" className="section-padding bg-[var(--background-light)]" data-name="about" data-file="components/About.js">
        <div className="container-max">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[var(--text-dark)] mb-6">
              Notre Histoire
            </h2>
            <p className="text-xl text-[var(--text-light)] max-w-3xl mx-auto">
              Depuis 2011, Roma Restaurant & Hotel incarne l'art de vivre italien à Libreville
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
                alt="Intérieur élégant du Roma Restaurant"
                className="rounded-lg shadow-lg w-full h-96 object-cover"
              />
            </div>
            
            <div className="space-y-6">
              <h3 className="text-3xl font-bold text-[var(--text-dark)]">
                Un concept unique à Libreville
              </h3>
              <p className="text-lg text-[var(--text-light)]">
                Fondé par Luca avec la vision de créer un véritable coin d'Italie en Afrique, 
                Roma Restaurant & Hotel combine l'authenticité de la gastronomie italienne 
                avec l'hospitalité africaine.
              </p>
              <p className="text-lg text-[var(--text-light)]">
                Sous la direction du chef Michele, notre cuisine propose des plats italiens 
                raffinés préparés avec des ingrédients de qualité supérieure, dans un cadre 
                élégant et chaleureux.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-[var(--primary-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                    <div className="icon-award text-2xl text-white"></div>
                  </div>
                  <h4 className="font-bold text-[var(--text-dark)]">Qualité</h4>
                  <p className="text-sm text-[var(--text-light)]">Ingrédients premium</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-[var(--primary-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                    <div className="icon-heart text-2xl text-white"></div>
                  </div>
                  <h4 className="font-bold text-[var(--text-dark)]">Service</h4>
                  <p className="text-sm text-[var(--text-light)]">Attentionné et professionnel</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-[var(--primary-color)] rounded-full flex items-center justify-center mx-auto mb-4">
                    <div className="icon-home text-2xl text-white"></div>
                  </div>
                  <h4 className="font-bold text-[var(--text-dark)]">Ambiance</h4>
                  <p className="text-sm text-[var(--text-light)]">Élégante et chaleureuse</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('About component error:', error);
    return null;
  }
}