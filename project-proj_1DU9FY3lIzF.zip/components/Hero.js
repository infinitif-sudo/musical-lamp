function Hero() {
  try {
    return (
      <section id="home" className="relative min-h-screen flex items-center justify-center" data-name="hero" data-file="components/Hero.js">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1974&q=80)'
          }}
        ></div>
        <div className="absolute inset-0 hero-gradient"></div>
        
        <div className="relative z-10 text-center text-white container-max">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-shadow">
            Roma Restaurant & Hotel
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-shadow max-w-3xl mx-auto">
            Un coin d'Italie au cœur de Libreville depuis 2011
          </p>
          <p className="text-lg mb-12 text-shadow max-w-2xl mx-auto">
            Découvrez notre cuisine italienne raffinée et notre boutique-hôtel de charme 
            dans un cadre élégant avec jardin privé
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button 
              onClick={() => window.location.href = 'reservation.html'}
              className="btn-primary text-lg px-8 py-4"
            >
              <div className="icon-calendar text-xl mr-2"></div>
              Réserver une table
            </button>
            <button 
              onClick={() => window.location.href = 'hotel.html'}
              className="btn-secondary text-lg px-8 py-4"
            >
              <div className="icon-bed text-xl mr-2"></div>
              Réserver une chambre
            </button>
            <a 
              href="https://wa.me/24174449864" 
              target="_blank"
              className="bg-green-600 text-white px-8 py-4 rounded-lg font-medium transition-all duration-300 hover:bg-green-700 hover:shadow-lg text-lg flex items-center"
            >
              <div className="icon-message-circle text-xl mr-2"></div>
              Nous contacter
            </a>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Hero component error:', error);
    return null;
  }
}