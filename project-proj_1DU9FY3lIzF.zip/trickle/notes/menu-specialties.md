# Roma Restaurant - Spécialités Menu

## Menu Signature
- **Menu Dégustation Caviar** - Expérience gastronomique premium
- **Les Pâtes du ROMA** - Spécialité maison avec sauce secrète
- **Steak en Or** - Entrecôte premium avec feuille d'or comestible

## Événements Spéciaux
- Fête des Moules (événement saisonnier)
- Soirées Saint-Valentin avec menu spécial
- Menu dégustation Wagyu/Kobe (week-ends spéciaux)

## Informations Pratiques
- Réservations: 074-44-98-64
- Site web: www.romalibreville.com
- Horaires: 12h-15h (déjeuner), 19h-22h30/23h (dîner)
- Capacité: 3 salles + terrasse jardin