# Roma Restaurant & Hotel Website

## Overview
Professional website for Roma Restaurant & Hotel, an Italian restaurant and boutique hotel located in Libreville, Gabon. Established in 2011, it combines authentic Italian cuisine with African hospitality.

## Location
- **Address**: Montée de Louis, face au consulat du Ghana, Quartier Louis, Libreville, Gabon
- **GPS Coordinates**: 0.40644, 9.43243
- **Phone/WhatsApp**: +241 74 44 98 64

## Website Structure

### Main Pages
- **index.html**: Homepage with hero section, about, services overview, testimonials, and contact
- **restaurant.html**: Detailed restaurant information and menu (to be implemented)
- **hotel.html**: Hotel rooms and booking information (to be implemented)
- **galerie.html**: Photo gallery (to be implemented)
- **reservation.html**: Online booking system (to be implemented)
- **avis.html**: Customer reviews page (to be implemented)

### Key Features
- Responsive design with elegant Italian-inspired styling
- WhatsApp integration for instant contact
- Google Maps integration for location
- Multi-language support (French primary)
- SEO optimized with proper meta tags

## Design System
- **Primary Color**: Dark Red (#8B0000)
- **Secondary Color**: Gold (#DAA520)
- **Typography**: Georgia serif font family
- **Style**: Luxury/Corporate template with warm, elegant atmosphere

## Services
### Restaurant
- Italian haute cuisine
- Three elegant dining rooms + garden terrace
- Private spaces for events
- Hours: 12:00-22:30 (23:00 weekends)

### Hotel
- 12 renovated rooms with balconies
- 4-star boutique hotel amenities
- Air conditioning, satellite TV, fiber optic internet
- Free private parking

## Technical Stack
- React 18 with Babel
- TailwindCSS for styling
- Lucide icons
- Responsive mobile-first design
- No build process required