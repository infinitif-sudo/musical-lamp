function Testimonials() {
  try {
    const testimonials = [
      {
        text: "Très propre, calme, personnel disponible ; restaurant gastro exceptionnel !",
        author: "Marie L.",
        rating: 5
      },
      {
        text: "Risotto et veau délicieux... service pro et manager sympathique. Une adresse à retenir !",
        author: "Jean-Paul M.",
        rating: 5
      },
      {
        text: "Top-class service... great food... L'ambiance est parfaite pour un dîner romantique.",
        author: "Sarah K.",
        rating: 5
      }
    ];

    return (
      <section className="section-padding bg-[var(--primary-color)]" data-name="testimonials" data-file="components/Testimonials.js">
        <div className="container-max">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Avis de nos clients
            </h2>
            <p className="text-xl text-white opacity-90 max-w-3xl mx-auto">
              Découvrez ce que nos clients pensent de leur expérience Roma
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-lg">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <div key={i} className="icon-star text-[var(--secondary-color)] text-xl"></div>
                  ))}
                </div>
                <p className="text-[var(--text-light)] mb-4 italic">
                  "{testimonial.text}"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-[var(--primary-color)] rounded-full flex items-center justify-center mr-3">
                    <div className="icon-user text-white"></div>
                  </div>
                  <div>
                    <p className="font-bold text-[var(--text-dark)]">{testimonial.author}</p>
                    <p className="text-sm text-[var(--text-light)]">Client vérifié</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button 
              onClick={() => window.location.href = 'avis.html'}
              className="bg-white text-[var(--primary-color)] px-8 py-3 rounded-lg font-medium hover:bg-gray-100 transition-colors"
            >
              Voir tous les avis
            </button>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Testimonials component error:', error);
    return null;
  }
}