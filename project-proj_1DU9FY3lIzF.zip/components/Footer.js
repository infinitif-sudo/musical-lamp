function Footer() {
  try {
    return (
      <footer className="bg-[var(--accent-color)] text-white section-padding" data-name="footer" data-file="components/Footer.js">
        <div className="container-max">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="icon-utensils text-2xl text-[var(--secondary-color)]"></div>
                <div>
                  <h3 className="text-xl font-bold">Roma</h3>
                  <p className="text-sm text-gray-400">Restaurant & Hotel</p>
                </div>
              </div>
              <p className="text-gray-300 mb-4">
                Un coin d'Italie au cœur de Libreville depuis 2011
              </p>
              <div className="flex space-x-4">
                <a href="https://wa.me/24174449864" target="_blank" className="text-green-500 hover:text-green-400">
                  <div className="icon-message-circle text-xl"></div>
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-bold mb-4">Navigation</h4>
              <ul className="space-y-2">
                <li><a href="index.html" className="text-gray-300 hover:text-white">Accueil</a></li>
                <li><a href="restaurant.html" className="text-gray-300 hover:text-white">Restaurant</a></li>
                <li><a href="hotel.html" className="text-gray-300 hover:text-white">Hôtel</a></li>
                <li><a href="galerie.html" className="text-gray-300 hover:text-white">Galerie</a></li>
                <li><a href="reservation.html" className="text-gray-300 hover:text-white">Réservations</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-300">
                <li className="flex items-center">
                  <div className="icon-map-pin text-sm mr-2"></div>
                  Quartier Louis, Libreville
                </li>
                <li className="flex items-center">
                  <div className="icon-phone text-sm mr-2"></div>
                  +241 74 44 98 64
                </li>
                <li className="flex items-center">
                  <div className="icon-clock text-sm mr-2"></div>
                  12h - 22h30
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold mb-4">Horaires</h4>
              <ul className="space-y-2 text-gray-300">
                <li>Lundi - Vendredi</li>
                <li>12h00 - 22h30</li>
                <li className="pt-2">Samedi - Dimanche</li>
                <li>12h00 - 23h00</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8 text-center">
            <p className="text-gray-400">
              © 2024 Roma Restaurant & Hotel. Tous droits réservés.
            </p>
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error('Footer component error:', error);
    return null;
  }
}