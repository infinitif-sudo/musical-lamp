When project updates are made
- Always check if README.md needs to be updated with new features, pages, or changes
- Update the website structure section when new pages are added
- Update the technical information when dependencies or frameworks change
- Keep the project overview current with any business information changes
- Maintain accuracy of contact information and location details